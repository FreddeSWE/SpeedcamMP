load('speedcam')
setExtensionUnloadMode('speedcam', 'manual')
